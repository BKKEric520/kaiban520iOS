//
//  UITextView+MSHeight.h
//  lvpai
//
//  Created by MaShuai on 16/4/23.
//  Copyright © 2016年 司马帅帅. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextView (BKHeight)

//获取UITextView的高度
- (CGFloat)getTextViewHeight;

@end




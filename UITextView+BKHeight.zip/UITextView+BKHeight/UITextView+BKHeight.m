//
//  UITextView+MSHeight.m
//  lvpai
//
//  Created by MaShuai on 16/4/23.
//  Copyright © 2016年 司马帅帅. All rights reserved.
//

#import "UITextView+BKHeight.h"

@implementation UITextView (BKHeight)

- (CGFloat)getTextViewHeight
{
    CGSize fitSize = [self sizeThatFits:CGSizeMake(self.bounds.size.width, MAXFLOAT)];
    return fitSize.height;
}

@end
